import { dish } from './dish';

export class order{
    dishtype:dish;
    quantity:number;
}