import { Component, OnInit } from '@angular/core';
import { order } from '../order';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
 
  ammount:number;
  t:Date;

  constructor(private route: ActivatedRoute) { 
    this.t=null;
  }
  ngOnInit() {
    this.showtotal();
  }
  showtotal()
  {
    this.ammount=+this.route.snapshot.paramMap.get('id');
  }
  confirm()
  {
      this.t=new Date();
      this.t.setHours(this.t.getHours() + 5 );
  }
}
