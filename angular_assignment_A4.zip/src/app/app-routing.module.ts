import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { HeroCombinedComponent }   from './hero-combined/hero-combined.component';
import { HeroComponent } from './hero/hero.component';
import { HeroDetailComponent }  from './hero-detail/hero-detail.component';
import {HomeComponent} from './home/home.component';
import { MenuComponent } from './menu/menu.component';
import {CheckoutComponent} from './checkout/checkout.component'

  const routes: Routes = [
    { path:'', redirectTo: '/menu', pathMatch: 'full' },
    { path:'menu', component: MenuComponent },
    {path:'checkout/:id',component:CheckoutComponent}
];
@NgModule({
  declarations: [],
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }
