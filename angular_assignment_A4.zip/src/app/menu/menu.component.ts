import { Component, OnInit } from '@angular/core';
import {dish} from '../dish';
import {menu} from '../menulist';
import {MenuService} from '../menu.service';
import {OrderService} from '../order.service';
import { order } from '../order';
import {Router} from "@angular/router";
import { nullSafeIsEquivalent } from '@angular/compiler/src/output/output_ast';
@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  currentmenu:dish[];
  listorder=new Set<order>();
  bill:number;

  constructor(private menuservice:MenuService,private orderservice:OrderService,private router:Router) {
    this.listorder=null; 
    this.bill=0;
    this.calculatetotal=this.calculatetotal.bind(this);
   }

  ngOnInit() {
      this.getMenu() 
  }
  getMenu():void{
        this.menuservice.getmenu().subscribe(Dish=>this.currentmenu = Dish);
      }
  add(Dish:dish):void{
      var Obj =new order();
      Obj.dishtype=Dish;
      Obj.quantity=1;
      this.orderservice.addinlist(Obj);
      this.getorders();
  }
  remove(Order:order):void
  {
    this.orderservice.removefromlist(Order);
    this.getorders();
  }
  getorders():void{
    this.orderservice.getlist().subscribe(orders=>this.listorder = orders);
    }
 calculatetotal():void
  {  
   this.getorders();
   var num=0;
   this.listorder.forEach(function(value) {
     var obj=value;
     if (obj.dishtype.servings>=obj.quantity)
     {     
          num=num+obj.dishtype.price;
     }
      else
      {
          var n=Math.ceil(obj.quantity/obj.dishtype.servings);
          num+=n*obj.dishtype.price;
      }
  });
    this.bill=num;
   // console.log(this.bill);
    this.router.navigate(['checkout' ,this.bill]);
  }
}
