export class HeroClass {
    id: number;
    name: string;
  }