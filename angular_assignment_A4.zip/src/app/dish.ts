export class dish{
    name:string;
    price:number;
    servings:number;
    pic:string;
}