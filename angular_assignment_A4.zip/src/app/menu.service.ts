import { Injectable } from '@angular/core';
import {menu} from './menulist';
import {dish} from './dish';
import  {Observable,of} from 'rxjs'
@Injectable({
  providedIn: 'root'
})
export class MenuService {

  constructor() {}
  getmenu():Observable<dish[]>
  {
    var today=new Date();
    var d: number=today.getDay();
    return of(menu[d]);
  }
}
