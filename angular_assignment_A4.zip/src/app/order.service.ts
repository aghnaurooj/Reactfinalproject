import { Injectable } from '@angular/core';
import {order} from './order'
import  {Observable,of} from 'rxjs'
@Injectable({
  providedIn: 'root'
})
export class OrderService {
  tmp = new Set<order>();
  orderlist:Array<order> = [];
  temp:Array<order>;
  constructor() { }
   
  getlist():Observable<Set<order>>
  {
    return of(this.tmp);
  }
  addinlist(obj:order)
  {
     this.orderlist.push(obj);
     this.tmp.add(obj);
  }
  removefromlist(obj:order)
  {
    
     ///var num= this.orderlist.findIndex(obj);
   /*  this.temp=null;
     for (var n=0;n<this.orderlist.length;n++)
      {
        if (n!=num)
        {
           this.temp.push(this.orderlist[n]);
        }
      }
      this.orderlist=this.temp;*/
      this.tmp.delete(obj);
  }
}
