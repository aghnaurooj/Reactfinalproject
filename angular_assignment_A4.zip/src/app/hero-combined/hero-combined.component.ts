import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hero-combined',
  templateUrl: './hero-combined.component.html',
  styleUrls: ['./hero-combined.component.css']
})
export class HeroCombinedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
